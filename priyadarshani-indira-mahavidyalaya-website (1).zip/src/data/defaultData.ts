import { CollegeData } from '../types';

export const defaultCollegeData: CollegeData = {
  hero: {
    eyebrow: "Welcome to Priyadarshani Indira Mahavidyalaya",
    title: "Empowering Minds,",
    titleAccent: "Shaping Futures",
    tagline: "Empowering Education for a Better Tomorrow — where academic excellence meets holistic development in a vibrant campus environment in Odisha.",
    statStudents: "1200+",
    statTeachers: "45+",
    statEstablish: "1985",
    statSuccessRate: "94%"
  },
  notices: [
    {
      id: "exam-1",
      type: "exam",
      title: "All type of Exam notices for +2 & +3 updated for Semester II.",
      date: "2026-05-24",
      url: "#"
    },
    {
      id: "exam-2",
      type: "exam",
      title: "Practical Examination schedule for Science Stream (2026).",
      date: "2026-05-20",
      url: "#"
    },
    {
      id: "exam-3",
      type: "exam",
      title: "Download hall tickets for upcoming mid-term examinations.",
      date: "2026-05-15",
      url: "#"
    },
    {
      id: "news-1",
      type: "news",
      title: "Annual Sports Day achievements and highlights published.",
      date: "2026-05-25",
      url: "#"
    },
    {
      id: "news-2",
      type: "news",
      title: "Recent college achievements and state-level event coverage in local dailies.",
      date: "2026-05-22",
      url: "#"
    },
    {
      id: "news-3",
      type: "news",
      title: "Science exhibition innovation award received by student delegation.",
      date: "2026-05-18",
      url: "#"
    },
    {
      id: "results-1",
      type: "results",
      title: "This Year +3 Degree Final Year Results (2025-26 Session) published.",
      date: "2026-05-26",
      url: "#"
    },
    {
      id: "results-2",
      type: "results",
      title: "Previous Year Result Archives & Stream-wise Topper Lists.",
      date: "2025-06-30",
      url: "#"
    },
    {
      id: "results-3",
      type: "results",
      title: "Re-evaluation applications open for Semester IV and Part-II candidates.",
      date: "2026-05-10",
      url: "#"
    }
  ],
  about: {
    eyebrow: "About the Institution",
    title: "A Legacy of",
    titleAccent: "Academic Excellence",
    content: "Founded in 1985, Priyadarshani Indira Mahavidyalaya is one of the premier fully aided colleges in Odisha, dedicated to delivering quality higher education and fostering empowerment in students.",
    principalTitle: "Principal's Desk",
    principalText: "Education is not merely the accumulation of facts, but the preparation for life itself. At P.I. Mahavidyalaya, our focus is on holistic development, academic rigor, and fostering a spirit of inquiry and leadership among all our students.",
    principalAuthor: "Dr. A. K. Sharma",
    principalRole: "Principal, P.I. Mahavidyalaya",
    principalImagePlaceholder: "Dr. A.K. Sharma is an experienced scholar with over 25 years in collegiate administration."
  },
  courses: [
    {
      id: "course-1",
      name: "+2 Arts Stream",
      description: "Foundational higher secondary education equipping students with critical thinking, linguistic arts, and humanistic knowledge.",
      stream: "arts",
      subjects: ["English", "Odia", "History", "Political Science", "Economics", "Education", "Sociology", "Sanskrit"]
    },
    {
      id: "course-2",
      name: "+2 Science Stream",
      description: "Rigorous scientific foundation prepares students for professional engineering and medical streams.",
      stream: "science",
      subjects: ["Physics", "Chemistry", "Mathematics", "Biology", "Botany", "Zoology", "Information Technology"]
    },
    {
      id: "course-3",
      name: "+3 Degree Arts Programs",
      description: "Advanced undergraduate syllabus offering deep specialization in humanities, social sciences, and language streams.",
      stream: "degree",
      subjects: ["History Honours", "Economics Honours", "Political Science Honours", "Education Honours", "Odia Honours", "Geography Elective", "Philosophy", "SECC-II (Odia Communication)"]
    },
    {
      id: "course-4",
      name: "+3 Degree Science Programs",
      description: "In-depth undergraduate program with robust academic modules in natural sciences and mathematical modeling.",
      stream: "degree",
      subjects: ["Physics Honours", "Chemistry Honours", "Mathematics Honours", "Botany Honours", "Zoology Honours", "SECC-II (Practical Writing)"]
    }
  ],
  staff: [
    {
      id: "staff-1",
      name: "Dr. A. K. Sharma",
      role: "Principal & Head of IQAC",
      department: "Administration",
      type: "faculty"
    },
    {
      id: "staff-2",
      name: "Prof. Manasa Ranjan Panda",
      role: "HOD & Lecturer in History",
      department: "Humanities & Arts",
      type: "faculty"
    },
    {
      id: "staff-3",
      name: "Mrs. Priyadarshini Mohanty",
      role: "Assistant Professor in Chemistry",
      department: "Science Division",
      type: "faculty"
    },
    {
      id: "staff-4",
      name: "Mr. Biswajit Das",
      role: "Senior Instructor & Lab General Coordinator",
      department: "Physics Laboratory",
      type: "technical"
    },
    {
      id: "staff-5",
      name: "Mr. Ashok Kumar Rout",
      role: "Head Clerk & Administrative Supervisor",
      department: "College Office",
      type: "non-teaching"
    },
    {
      id: "staff-6",
      name: "Mrs. Sunita Patnaik",
      role: "Librarian & Cataloging Specialist",
      department: "Central Library",
      type: "technical"
    },
    {
      id: "staff-7",
      name: "Mr. Ranjan Kumar Nayak",
      role: "Accountant & Fees Collection In-charge",
      department: "Accounts Section",
      type: "non-teaching"
    }
  ],
  activities: [
    {
      id: "act-1",
      icon: "hands-helping",
      title: "NSS (National Service Scheme)",
      description: "Promoting social welfare, rural medical camps, winter extension projects, and civic responsibility among youth."
    },
    {
      id: "act-2",
      icon: "shield-alt",
      title: "NCC (National Cadet Corps)",
      description: "Instilling discipline, state-level parades, leadership camps, survival drills, and patriotic national defense skills."
    },
    {
      id: "act-3",
      icon: "medkit",
      title: "Youth Red Cross",
      description: "Focusing on emergency disaster response, first aid training, blood donation camps, and community hygiene initiatives."
    },
    {
      id: "act-4",
      icon: "bus-alt",
      title: "Educational Study Tours",
      description: "Annual field trips bridging campus theory and historic research, industrial spots, and ecological sanctuaries."
    },
    {
      id: "act-5",
      icon: "trophy",
      title: "State Achievements",
      description: "Outstanding students winning state laureates in inter-college sports tracks, debates, and annual science exhibitions."
    }
  ],
  admissions: {
    eyebrow: "Admissions 2026–27",
    title: "Start Your Beautiful",
    titleAccent: "Academic Journey",
    description: "Our admission process is fully coordinated, transparent, and designed according to Odisha SAMS guidelines and merit ranking.",
    steps: [
      {
        stepNum: 1,
        title: "SAMS Odisha Online Registration",
        desc: "Submit your Common Application Form (CAF) online via SAMS Odisha portal and select Priyadarshani Indira Mahavidyalaya as your preferred choice."
      },
      {
        stepNum: 2,
        title: "Merit List Publication & Selection",
        desc: "Check selection round status. Merit reports are also published on our local college notice board."
      },
      {
        stepNum: 3,
        title: "Verification & Seat Enrollment",
        desc: "Bring original matriculation/secondary certificates, CLC (College Leaving Certificate), and migration forms for face-to-face registration."
      }
    ],
    importantDates: [
      {
        event: "SAMS Application Window",
        date: "June 05 – June 28, 2026"
      },
      {
        event: "First Selection Admission Process",
        date: "July 05 – July 10, 2026"
      },
      {
        event: "Second Selection & Spot Admission",
        date: "July 18 – July 22, 2026"
      },
      {
        event: "Inauguration & Classes Commence",
        date: "August 01, 2026"
      }
    ],
    eligibilityTitle: "Admission Eligibility Standards",
    eligibilityItems: [
      "For +2 Programs: SAMS CAF selection with valid 10th Board Certificate.",
      "For +3 Degree Programs: SAMS CAF selection with 10+2 Arts/Science passing certificate.",
      "Odia is mandatory as MIL subject or secondary school exam standard unless special exemption is granted."
    ]
  },
  contact: {
    address: "Priyadarshini Indira Mahavidyalaya, Junagarh, Kalahandi, Odisha, Pin-766014.",
    email: "info@pimahavidyalaya.in",
    phone: "+91 674 - 2390XXX",
    website: "https://pimahavidyalaya.in"
  }
};
