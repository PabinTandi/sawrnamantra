import { useState } from 'react';
import { AdmissionsState, AdmissionStep, ImportantDate } from '../types';
import { 
  GraduationCap, Calendar, CheckSquare, Edit, Save, Undo2, 
  Sparkles, CheckCircle2, ChevronRight, HelpCircle, FileText 
} from 'lucide-react';

interface AdmissionsSectionProps {
  data: AdmissionsState;
  isAdmin: boolean;
  onUpdate: (updated: AdmissionsState) => void;
}

export default function AdmissionsSection({ data, isAdmin, onUpdate }: AdmissionsSectionProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<AdmissionsState>({ ...data });

  const handleStartEdit = () => {
    setFormData({ ...data });
    setIsEditing(true);
  };

  const handleSave = () => {
    onUpdate(formData);
    setIsEditing(false);
  };

  const handleStepChange = (index: number, key: keyof AdmissionStep, val: string | number) => {
    const updatedSteps = formData.steps.map((step, idx) => 
      idx === index ? { ...step, [key]: val } : step
    );
    setFormData(prev => ({ ...prev, steps: updatedSteps }));
  };

  const handleDateChange = (index: number, key: keyof ImportantDate, val: string) => {
    const updatedDates = formData.importantDates.map((item, idx) =>
      idx === index ? { ...item, [key]: val } : item
    );
    setFormData(prev => ({ ...prev, importantDates: updatedDates }));
  };

  const handleAddDate = () => {
    setFormData(prev => ({
      ...prev,
      importantDates: [...prev.importantDates, { event: 'New SAMS Phase', date: 'Declare soon, 2026' }]
    }));
  };

  const handleRemoveDate = (index: number) => {
    setFormData(prev => ({
      ...prev,
      importantDates: prev.importantDates.filter((_, idx) => idx !== index)
    }));
  };

  return (
    <section id="admissions" className="py-24 bg-white select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Admin configure button */}
        {isAdmin && !isEditing && (
          <div className="flex justify-end mb-4">
            <button
              onClick={handleStartEdit}
              className="bg-amber-500 hover:bg-amber-400 text-navy font-extrabold text-xs px-3.5 py-2 rounded-lg flex items-center gap-1.5 shadow"
            >
              <Edit className="w-4 h-4 stroke-[2.5]" />
              <span>Modify Admission Process & Calendar</span>
            </button>
          </div>
        )}

        {isEditing ? (
          /* Large structured editor sheet */
          <div className="bg-slate-50 border-2 border-navy border-dashed rounded-2xl p-6 mb-12 animate-fade-up text-xs font-sans text-slate-700">
            <div className="flex justify-between items-center pb-3 border-b mb-6 select-none">
              <span className="text-navy font-bold font-serif text-base uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-5 h-5 text-gold" />
                <span>Admissions Setup & Phase Date Editor</span>
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => setIsEditing(false)}
                  className="px-2.5 py-1.5 bg-slate-300 text-slate-700 font-bold rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="px-2.5 py-1.5 bg-navy text-white font-bold rounded"
                >
                  Apply Setup
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
              
              {/* Left Column: Core Header copy and Timeline dates */}
              <div className="space-y-4">
                <div>
                  <h4 className="font-bold text-navy text-[11px] mb-2 uppercase tracking-wider">Timeline Milestones</h4>
                  <div className="space-y-2 border p-3 rounded-lg bg-white">
                    {formData.importantDates.map((item, idx) => (
                      <div key={idx} className="flex gap-2 items-center">
                        <input
                          type="text"
                          value={item.event}
                          onChange={(e) => handleDateChange(idx, 'event', e.target.value)}
                          placeholder="Event Title"
                          className="flex-1 bg-slate-50 border p-1 rounded font-medium text-xs text-navy outline-none"
                        />
                        <input
                          type="text"
                          value={item.date}
                          onChange={(e) => handleDateChange(idx, 'date', e.target.value)}
                          placeholder="Date spec"
                          className="w-1/3 bg-slate-50 border p-1 rounded text-xs text-slate-800 outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => handleRemoveDate(idx)}
                          className="text-red-500 font-bold p-1 hover:bg-red-50 rounded"
                          title="Remove milestone"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                    <button
                      type="button"
                      onClick={handleAddDate}
                      className="w-full border-2 border-dashed border-slate-300 text-slate-500 font-bold py-1.5 rounded hover:bg-slate-50 text-[10px]"
                    >
                      + Add SAMS Milestone Date
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-600 uppercase tracking-wider mb-1">Standard Eligibility Box Title</label>
                  <input
                    type="text"
                    value={formData.eligibilityTitle}
                    onChange={(e) => setFormData(prev => ({ ...prev, eligibilityTitle: e.target.value }))}
                    className="w-full bg-white border border-slate-200 p-2 rounded text-xs outline-none"
                  />
                </div>
              </div>

              {/* Right Column: Admission Process Common Steps */}
              <div className="space-y-4">
                <h4 className="font-bold text-navy text-[11px] uppercase tracking-wider">Admission Steps</h4>
                <div className="space-y-3">
                  {formData.steps.map((step, idx) => (
                    <div key={idx} className="border p-3.5 rounded-lg bg-white space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-navy font-serif text-xs">Step #{step.stepNum}</span>
                      </div>
                      <input
                        type="text"
                        value={step.title}
                        onChange={(e) => handleStepChange(idx, 'title', e.target.value)}
                        placeholder="Step Title"
                        className="w-full bg-slate-50 border p-1.5 rounded font-semibold text-xs text-navy outline-none"
                      />
                      <textarea
                        rows={2}
                        value={step.desc}
                        onChange={(e) => handleStepChange(idx, 'desc', e.target.value)}
                        placeholder="Description narrative"
                        className="w-full bg-slate-50 border p-1.5 rounded text-xs text-slate-700 outline-none resize-none"
                      />
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        ) : (
          /* Public Admissions viewport */
          <>
            {/* Intro Header */}
            <div className="text-center max-w-3xl mx-auto mb-16 animate-fade-up">
              <span className="bg-navy/10 text-navy px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">
                {data.eyebrow}
              </span>
              <h2 className="font-serif font-bold text-3xl sm:text-4xl text-navy mt-4">
                {data.title} <span className="text-gold">{data.titleAccent}</span>
              </h2>
              <div className="w-[60px] h-1 bg-gold mx-auto mt-4 mb-4 rounded" />
              <p className="text-slate-500 text-sm sm:text-base max-w-xl mx-auto">
                {data.description}
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
              
              {/* Left detail grid - Step guides */}
              <div className="lg:col-span-7 space-y-8 animate-fade-up">
                <h3 className="font-serif font-extrabold text-navy text-lg sm:text-xl flex items-center gap-2 mb-6 border-b pb-2">
                  <span className="w-1.5 h-6 bg-gold rounded" />
                  <span>Odisha SAMS Online Process</span>
                </h3>

                <div className="relative pl-6 space-y-10 border-l-2 border-slate-200">
                  {data.steps.map((step) => (
                    <div key={step.stepNum} className="relative">
                      {/* Floating list number counter */}
                      <span className="absolute -left-[45px] top-0.5 w-[38px] h-[38px] bg-navy text-gold-light rounded-full flex items-center justify-center font-serif font-bold text-sm shadow">
                        {step.stepNum}
                      </span>
                      <div className="pl-4">
                        <h4 className="font-bold text-navy text-base tracking-tight mb-1">{step.title}</h4>
                        <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">{step.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right panel detail card - Calendars & Standards */}
              <div className="lg:col-span-5 space-y-6 animate-fade-up">
                
                {/* Important Dates Calendar card */}
                <div className="bg-slate-900 text-white rounded-3xl p-6.5 shadow-xl border border-white/5 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                    <Calendar className="w-24 h-24 text-white" />
                  </div>

                  <h4 className="font-serif font-extrabold text-gold-light text-base uppercase tracking-wider mb-4 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gold stroke-[2.5]" />
                    <span>Important SAMS Deadlines</span>
                  </h4>

                  <div className="divide-y divide-white/10 text-xs leading-relaxed">
                    {data.importantDates.map((item, idx) => (
                      <div key={idx} className="py-3 flex items-center justify-between gap-4 font-medium">
                        <span className="text-white/85 tracking-tight">{item.event}</span>
                        <span className="text-gold font-bold shrink-0">{item.date}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Eligibility requirements */}
                <div className="bg-slate-50 border border-slate-200 rounded-3xl p-6 shadow-sm">
                  <h4 className="font-serif font-extrabold text-navy text-sm uppercase tracking-wide mb-4 flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-navy" />
                    <span>{data.eligibilityTitle}</span>
                  </h4>
                  
                  <ul className="space-y-3 text-xs leading-relaxed text-slate-600 font-medium">
                    {data.eligibilityItems.map((item, i) => (
                      <li key={i} className="flex gap-2 items-start">
                        <CheckCircle2 className="w-4.5 h-4.5 text-gold shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

              </div>

            </div>
          </>
        )}

      </div>
    </section>
  );
}
