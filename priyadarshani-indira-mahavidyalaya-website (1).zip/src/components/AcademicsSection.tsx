import React, { useState } from 'react';
import { CourseState, CourseStream } from '../types';
import { 
  GraduationCap, Search, Plus, Trash2, Edit, Save, BookOpen, 
  FileDown, Download, Check, Sparkles, FolderOpen, Heart, AlertCircle 
} from 'lucide-react';

interface AcademicsSectionProps {
  courses: CourseState[];
  isAdmin: boolean;
  onUpdate: (updated: CourseState[]) => void;
}

export default function AcademicsSection({ courses, isAdmin, onUpdate }: AcademicsSectionProps) {
  const [activeStream, setActiveStream] = useState<'all' | CourseStream>('all');
  const [subjSearch, setSubjSearch] = useState('');
  
  // Edit Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [courseName, setCourseName] = useState('');
  const [courseDesc, setCourseDesc] = useState('');
  const [courseStream, setCourseStream] = useState<CourseStream>('arts');
  const [courseSubjects, setCourseSubjects] = useState('');

  // Course filter
  const filteredCourses = courses.filter((course) => {
    const streamMatch = activeStream === 'all' || course.stream === activeStream;
    const searchMatch = 
      course.name.toLowerCase().includes(subjSearch.toLowerCase()) || 
      course.subjects.some(sub => sub.toLowerCase().includes(subjSearch.toLowerCase()));
    return streamMatch && searchMatch;
  });

  // Action saves course
  const handleSaveCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseName.trim()) return;

    const parsedSubjects = courseSubjects
      .split(',')
      .map(part => part.trim())
      .filter(part => part.length > 0);

    if (editingId === 'new') {
      const newCourse: CourseState = {
        id: `course-${Date.now()}`,
        name: courseName,
        description: courseDesc,
        stream: courseStream,
        subjects: parsedSubjects
      };
      onUpdate([...courses, newCourse]);
    } else if (editingId) {
      const updated = courses.map(item => 
        item.id === editingId 
          ? { ...item, name: courseName, description: courseDesc, stream: courseStream, subjects: parsedSubjects } 
          : item
      );
      onUpdate(updated);
    }
    resetForm();
  };

  const resetForm = () => {
    setEditingId(null);
    setCourseName('');
    setCourseDesc('');
    setCourseStream('arts');
    setCourseSubjects('');
  };

  const handleEditClick = (course: CourseState) => {
    setEditingId(course.id);
    setCourseName(course.name);
    setCourseDesc(course.description);
    setCourseStream(course.stream);
    setCourseSubjects(course.subjects.join(', '));
  };

  const handleDeleteClick = (id: string) => {
    if (window.confirm('Delete this course standard? This cannot be undone.')) {
      onUpdate(courses.filter(item => item.id !== id));
    }
  };

  const handleStartAdd = () => {
    resetForm();
    setEditingId('new');
  };

  return (
    <section id="academics" className="py-24 bg-slate-50 select-none border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Intro */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="bg-navy-light/10 text-navy-light px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">
            Programs of Study
          </span>
          <h2 className="font-serif font-bold text-3xl sm:text-4xl text-navy mt-4">
            Curriculum & <span className="text-gold">Syllabus Directory</span>
          </h2>
          <div className="w-[60px] h-1 bg-gold mx-auto mt-4 mb-4 rounded" />
          <p className="text-slate-500 text-sm sm:text-base leading-relaxed">
            Choose from vocational secondary standards or high specialization undergraduate Honors degrees affiliated under state directives.
          </p>
        </div>

        {/* Dashboard Control filter */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4 mb-10">
          
          <div className="flex bg-slate-100 p-1 rounded-lg w-full md:w-auto overflow-x-auto select-none">
            {(['all', 'arts', 'science', 'degree'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveStream(tab)}
                className={`px-4 py-2.5 text-xs font-extrabold rounded-md uppercase tracking-wider transition-all whitespace-nowrap focus:outline-none ${
                  activeStream === tab 
                    ? 'bg-navy text-white shadow' 
                    : 'text-slate-600 hover:text-navy hover:bg-slate-200/40'
                }`}
              >
                {tab === 'all' ? 'All Programs' : tab === 'arts' ? '+2 Arts' : tab === 'science' ? '+2 Science' : '+3 Undergraduate'}
              </button>
            ))}
          </div>

          <div className="relative w-full md:max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search course or subjects..."
              value={subjSearch}
              onChange={(e) => setSubjSearch(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 pl-9 pr-4 py-2 rounded-lg text-sm outline-none focus:bg-white focus:border-navy"
            />
          </div>

        </div>

        {/* Courses & Administration Workspace Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Main Course Listing card blocks */}
          <div className="col-span-1 lg:col-span-8 space-y-6">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredCourses.length > 0 ? (
                filteredCourses.map((course) => (
                  <div
                    key={course.id}
                    className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm hover:shadow-lg transition-all relative flex flex-col min-h-[280px]"
                  >
                    {/* Header badge */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded uppercase ${
                        course.stream === 'arts' ? 'bg-indigo-50 text-indigo-600 border border-indigo-200' :
                        course.stream === 'science' ? 'bg-sky-50 text-sky-600 border border-sky-200' :
                        'bg-amber-100 text-amber-800 border border-amber-300'
                      }`}>
                        {course.stream}
                      </span>
                      
                      {isAdmin && (
                        <div className="flex gap-1">
                          <button
                            onClick={() => handleEditClick(course)}
                            className="p-1 text-slate-400 hover:text-navy hover:bg-slate-100 rounded"
                            title="Edit course syllabus"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteClick(course.id)}
                            className="p-1 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded"
                            title="Remove Course banner"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>

                    <h4 className="font-serif font-bold text-lg text-navy mb-1.5">
                      {course.name}
                    </h4>
                    <p className="text-slate-500 text-xs leading-relaxed mb-4 flex-1">
                      {course.description}
                    </p>

                    {/* Subject Pill Grid */}
                    <div>
                      <div className="text-[10px] font-bold uppercase text-slate-400 tracking-wider mb-2">Subject Modules</div>
                      <div className="flex flex-wrap gap-1.5">
                        {course.subjects.map((sub, i) => (
                          <span
                            key={i}
                            className="text-[10px] font-semibold text-navy bg-slate-100/90 hover:bg-gold-pale/50 border border-slate-200 shadow-inner px-2 py-1 rounded"
                          >
                            {sub}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-1 md:col-span-2 bg-white border border-slate-200 rounded-2xl p-12 text-center text-slate-500">
                  <AlertCircle className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="font-semibold text-sm">No educational streams match SAMS criteria filters.</p>
                </div>
              )}
            </div>

            {/* Admin Add Buttons */}
            {isAdmin && !editingId && (
              <button
                onClick={handleStartAdd}
                className="bg-navy hover:bg-navy-light text-white font-bold text-xs px-4 py-2.5 rounded-lg flex items-center gap-1.5 shadow"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>Add Custom Stream / Class Syllabus</span>
              </button>
            )}

          </div>

          {/* Form container / Downloads panel */}
          <div className="col-span-1 lg:col-span-4">
            
            {editingId ? (
              /* Course Editor Drawer */
              <form onSubmit={handleSaveCourse} className="bg-white border-2 border-navy rounded-2xl p-6 shadow-xl space-y-4">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200 mb-2">
                  <span className="font-serif font-black text-navy text-sm uppercase tracking-wider">
                    {editingId === 'new' ? 'New Syllabus Form' : 'Course Configuration'}
                  </span>
                  <button
                    type="button"
                    onClick={resetForm}
                    className="text-xs text-slate-400 hover:text-slate-600 font-bold"
                  >
                    Cancel
                  </button>
                </div>

                <div>
                  <label className="block text-slate-600 text-[10px] font-black uppercase tracking-wider mb-1">Course Identity Name *</label>
                  <input
                    type="text"
                    value={courseName}
                    onChange={(e) => setCourseName(e.target.value)}
                    required
                    placeholder="e.g., +3 Physics Honors"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-sm text-navy outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 text-[10px] font-black uppercase tracking-wider mb-1">Stream Classification</label>
                    <select
                      value={courseStream}
                      onChange={(e) => setCourseStream(e.target.value as CourseStream)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs text-navy outline-none"
                    >
                      <option value="arts">Arts Stream</option>
                      <option value="science">Science Stream</option>
                      <option value="degree">Undergrad Honors (+3)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-600 text-[10px] font-black uppercase tracking-wider mb-1">Stream Slogan Narrative</label>
                  <textarea
                    rows={3}
                    value={courseDesc}
                    onChange={(e) => setCourseDesc(e.target.value)}
                    placeholder="Add brief description regarding career prospects or honors..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs text-slate-800 outline-none resize-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 text-[10px] font-black uppercase tracking-wider mb-1">Subject Modules (Comma separated)</label>
                  <input
                    type="text"
                    value={courseSubjects}
                    onChange={(e) => setCourseSubjects(e.target.value)}
                    placeholder="e.g., Botany, Zoology, Chemistry, Odia"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-[11px] text-navy outline-none"
                  />
                  <span className="text-[10px] text-slate-400 block mt-1">Separate subject elements with commas.</span>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gold hover:bg-gold-light text-navy font-bold py-2.5 rounded-lg text-xs tracking-wider uppercase shadow"
                >
                  Save Educational Stream
                </button>
              </form>
            ) : (
              /* Public Downloads widget panel */
              <div className="bg-navy text-white rounded-2xl p-6 shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-5">
                  <GraduationCap className="w-24 h-24 text-white" />
                </div>

                <h3 className="font-serif font-extrabold text-lg text-white mb-2">
                  Academic <span className="text-gold-light">Syllabus Desk</span>
                </h3>
                <p className="text-white/70 text-xs leading-relaxed mb-6">
                  Select and download official syllabus materials containing subject weightage, internal metrics models, and test rubrics mapped to Odisha University standards.
                </p>

                <div className="space-y-3">
                  <a
                    href="#"
                    className="bg-white/10 hover:bg-white/15 border border-white/10 p-3.5 rounded-xl flex items-center justify-between text-xs font-semibold tracking-wider transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <FolderOpen className="text-gold w-4 h-4" />
                      <span>+2 Syllabus (Arts/Sci)</span>
                    </span>
                    <Download className="w-4 h-4 text-white/60" />
                  </a>

                  <a
                    href="#"
                    className="bg-white/10 hover:bg-white/15 border border-white/10 p-3.5 rounded-xl flex items-center justify-between text-xs font-semibold tracking-wider transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <FolderOpen className="text-gold w-4 h-4" />
                      <span>+3 Degree Syllabus Pack</span>
                    </span>
                    <Download className="w-4 h-4 text-white/60" />
                  </a>

                  <a
                    href="#"
                    className="bg-white/10 hover:bg-white/15 border border-white/10 p-3.5 rounded-xl flex items-center justify-between text-xs font-semibold tracking-wider transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <FileDown className="text-gold w-4 h-4" />
                      <span>SECC-II Elective syllabus</span>
                    </span>
                    <Download className="w-4 h-4 text-white/60" />
                  </a>
                </div>

                <div className="border-t border-white/10 mt-6 pt-4 flex gap-1.5 items-center">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full shrink-0" />
                  <span className="text-[10px] text-white/50 font-bold uppercase tracking-widest">Modified: June 2026</span>
                </div>
              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
}
