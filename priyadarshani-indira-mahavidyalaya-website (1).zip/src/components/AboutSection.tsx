import React, { useState } from 'react';
import { AboutState } from '../types';
import { Award, BookOpen, Quote, Edit, Save, Undo2, Sparkles, UserCheck } from 'lucide-react';

interface AboutSectionProps {
  data: AboutState;
  isAdmin: boolean;
  onUpdate: (updated: AboutState) => void;
}

export default function AboutSection({ data, isAdmin, onUpdate }: AboutSectionProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<AboutState>({ ...data });

  const handleStartEdit = () => {
    setFormData({ ...data });
    setIsEditing(true);
  };

  const handleSave = () => {
    onUpdate(formData);
    setIsEditing(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <section id="about" className="py-24 bg-white select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editor controls toggle */}
        {isAdmin && !isEditing && (
          <div className="flex justify-end mb-4 animate-fade-up">
            <button
              onClick={handleStartEdit}
              className="bg-amber-500 hover:bg-amber-400 text-navy font-extrabold text-xs px-3.5 py-2 rounded-lg flex items-center gap-1.5 shadow"
            >
              <Edit className="w-4 h-4 stroke-[2.5]" />
              <span>Modify About Section & Message</span>
            </button>
          </div>
        )}

        {isEditing ? (
          /* Editor form card */
          <div className="bg-slate-50 border-2 border-dashed border-navy rounded-2xl p-8 mb-12 animate-fade-up">
            <div className="flex justify-between items-center pb-3 border-b border-slate-200 mb-6">
              <span className="text-navy font-bold font-serif text-base uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4.5 h-4.5 text-gold" />
                <span>About Details Customize Module</span>
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => setIsEditing(false)}
                  className="px-3 py-1.5 text-xs bg-slate-300 text-slate-700 hover:bg-slate-400/50 rounded font-bold"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="px-3 py-1.5 text-xs bg-navy text-white hover:bg-navy-light rounded font-bold"
                >
                  Save Section
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-700 font-sans">
              <div className="space-y-4">
                <div>
                  <label className="block text-slate-600 font-bold mb-1 uppercase tracking-wider">Institution Tagline Badge</label>
                  <input
                    type="text"
                    name="eyebrow"
                    value={formData.eyebrow}
                    onChange={handleChange}
                    className="w-full bg-white border border-slate-300 px-3 py-2 rounded text-slate-800 text-sm outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-bold mb-1 uppercase tracking-wider">Main Header Tag</label>
                  <input
                    type="text"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    className="w-full bg-white border border-slate-300 px-3 py-2 rounded text-slate-800 text-sm outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-bold mb-1 uppercase tracking-wider">Accent Column Header</label>
                  <input
                    type="text"
                    name="titleAccent"
                    value={formData.titleAccent}
                    onChange={handleChange}
                    className="w-full bg-white border border-slate-300 px-3 py-2 rounded text-slate-800 text-sm outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-bold mb-1 uppercase tracking-wider">Institutional Biography Paragraph</label>
                  <textarea
                    name="content"
                    rows={4}
                    value={formData.content}
                    onChange={handleChange}
                    className="w-full bg-white border border-slate-300 px-3 py-2 rounded text-slate-800 text-sm outline-none resize-none"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-slate-600 font-bold mb-1 uppercase tracking-wider">Welcome Box Title</label>
                  <input
                    type="text"
                    name="principalTitle"
                    value={formData.principalTitle}
                    onChange={handleChange}
                    className="w-full bg-white border border-slate-300 px-3 py-2 rounded text-slate-800 text-sm outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-bold mb-1 uppercase tracking-wider">Principal Quote Message</label>
                  <textarea
                    name="principalText"
                    rows={4}
                    value={formData.principalText}
                    onChange={handleChange}
                    className="w-full bg-white border border-slate-300 px-3 py-2 rounded text-slate-800 text-sm outline-none resize-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 font-bold mb-1 uppercase tracking-wider">Principal Full Name</label>
                    <input
                      type="text"
                      name="principalAuthor"
                      value={formData.principalAuthor}
                      onChange={handleChange}
                      className="w-full bg-white border border-slate-300 px-3 py-2 rounded text-slate-800 text-xs outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-bold mb-1 uppercase tracking-wider">Principal Suffix Designation</label>
                    <input
                      type="text"
                      name="principalRole"
                      value={formData.principalRole}
                      onChange={handleChange}
                      className="w-full bg-white border border-slate-300 px-3 py-2 rounded text-slate-800 text-xs outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Public layout view */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-center">
            
            {/* Left side Collage with Badge box */}
            <div className="lg:col-span-5 relative flex items-center justify-center animate-fade-up">
              <div className="w-full aspect-[4/3] max-w-md bg-gradient-to-tr from-navy to-navy-light rounded-[2rem] p-1.5 shadow-2xl relative group">
                <div className="w-full h-full bg-slate-900 rounded-[1.8rem] overflow-hidden flex flex-col items-center justify-center p-6 text-center select-none relative">
                  
                  {/* Backdrop art layout */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent z-10" />
                  
                  <div className="w-16 h-16 bg-gold-pale/10 text-gold rounded-2xl flex items-center justify-center text-4xl mb-3 relative z-20 transition-transform duration-300 group-hover:scale-110">
                    🏛️
                  </div>
                  <h3 className="font-serif text-white font-extrabold text-base sm:text-lg mb-2 relative z-20">Main Entrance gate</h3>
                  <p className="text-white/60 text-[11px] leading-relaxed max-w-[200px] relative z-20">
                    PIDC administrative building covers smart rooms, labs, and centralized resources.
                  </p>
                </div>
              </div>

              {/* Float Institution Badge */}
              <div className="absolute -bottom-6 -right-4 sm:-right-8 bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xl flex items-center gap-3.5 max-w-[240px]">
                <div className="w-11 h-11 bg-gold-pale rounded-xl flex items-center justify-center text-gold shrink-0">
                  <Award className="w-5 h-5 stroke-[2.5]" />
                </div>
                <div>
                  <div className="font-serif font-extrabold text-navy text-xl leading-none">38+</div>
                  <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider mt-1">Years of Excellence</div>
                </div>
              </div>
            </div>

            {/* Right side narrative paragraph + Principal welcome letters */}
            <div className="lg:col-span-7 flex flex-col items-start animate-fade-up">
              
              <span className="bg-gold-pale text-gold border border-gold/15 text-[11px] font-extrabold tracking-widest uppercase px-3 py-1 rounded-full mb-4">
                {data.eyebrow}
              </span>

              <h2 className="font-serif font-bold text-3xl sm:text-4xl lg:text-5xl text-navy leading-tight mb-2">
                {data.title}
                <span className="block text-gold font-serif font-black">{data.titleAccent}</span>
              </h2>

              <p className="text-slate-600 text-sm sm:text-base leading-relaxed mt-4 mb-6 font-medium">
                {data.content}
              </p>

              {/* Principal Message Segment */}
              <div className="bg-slate-50 border-l-4 border-navy rounded-r-2xl p-6 relative w-full leading-relaxed shadow-sm">
                <Quote className="w-12 h-12 text-slate-200 absolute -top-4 right-4 stroke-[1.5]" />
                <h4 className="font-serif font-bold text-navy text-sm sm:text-base mb-3 flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-navy" />
                  <span>{data.principalTitle}</span>
                </h4>
                <p className="text-slate-600 italic text-[13px] sm:text-sm leading-relaxed mb-4 relative z-10">
                  "{data.principalText}"
                </p>
                <div className="border-t border-slate-200/50 pt-3 flex items-center justify-between">
                  <div>
                    <h5 className="font-bold text-navy text-sm">{data.principalAuthor}</h5>
                    <p className="text-slate-400 text-xs">{data.principalRole}</p>
                  </div>
                </div>
              </div>

            </div>

          </div>
        )}

      </div>
    </section>
  );
}
