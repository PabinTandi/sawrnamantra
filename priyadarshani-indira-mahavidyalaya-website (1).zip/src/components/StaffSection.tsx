import React, { useState } from 'react';
import { StaffState, StaffType } from '../types';
import { 
  Users, UserCheck, ShieldCheck, Search, Plus, Trash2, 
  Edit, Save, X, Sparkles, HelpCircle, Briefcase, Award 
} from 'lucide-react';

interface StaffSectionProps {
  staff: StaffState[];
  isAdmin: boolean;
  onUpdate: (updated: StaffState[]) => void;
}

export default function StaffSection({ staff, isAdmin, onUpdate }: StaffSectionProps) {
  const [activeType, setActiveType] = useState<'all' | StaffType>('all');
  const [staffSearch, setStaffSearch] = useState('');

  // Edit states
  const [editingId, setEditingId] = useState<string | null>(null);
  const [staffName, setStaffName] = useState('');
  const [staffRole, setStaffRole] = useState('');
  const [staffDept, setStaffDept] = useState('');
  const [staffType, setStaffType] = useState<StaffType>('faculty');

  // Search filtered
  const filteredStaff = staff.filter(item => {
    const typeMatch = activeType === 'all' || item.type === activeType;
    const searchMatch = 
      item.name.toLowerCase().includes(staffSearch.toLowerCase()) ||
      item.role.toLowerCase().includes(staffSearch.toLowerCase()) ||
      item.department.toLowerCase().includes(staffSearch.toLowerCase());
    return typeMatch && searchMatch;
  });

  const handleSaveStaff = (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffName.trim()) return;

    if (editingId === 'new') {
      const newStaff: StaffState = {
        id: `staff-${Date.now()}`,
        name: staffName,
        role: staffRole,
        department: staffDept,
        type: staffType
      };
      onUpdate([...staff, newStaff]);
    } else if (editingId) {
      const updated = staff.map(item =>
        item.id === editingId
          ? { ...item, name: staffName, role: staffRole, department: staffDept, type: staffType }
          : item
      );
      onUpdate(updated);
    }
    resetForm();
  };

  const resetForm = () => {
    setEditingId(null);
    setStaffName('');
    setStaffRole('');
    setStaffDept('');
    setStaffType('faculty');
  };

  const handleEditClick = (item: StaffState) => {
    setEditingId(item.id);
    setStaffName(item.name);
    setStaffRole(item.role);
    setStaffDept(item.department);
    setStaffType(item.type);
  };

  const handleDeleteClick = (id: string) => {
    if (window.confirm('Remove this staff record from our public roster?')) {
      onUpdate(staff.filter(item => item.id !== id));
    }
  };

  const handleStartAdd = () => {
    resetForm();
    setEditingId('new');
  };

  return (
    <section id="staff" className="py-24 bg-white select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Intro Tagline */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="bg-gold-pale text-gold border border-gold/15 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">
            Governance & Faculty
          </span>
          <h2 className="font-serif font-bold text-3xl sm:text-4xl text-navy mt-4">
            Our Dedicated <span className="text-gold">College Roster</span>
          </h2>
          <div className="w-[60px] h-1 bg-gold mx-auto mt-4 mb-4 rounded" />
          <p className="text-slate-500 text-sm">
            Meet our esteemed professors, technicians, and administrators ensuring seamless operational and academic success.
          </p>
        </div>

        {/* Filters and search roster */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4 mb-10">
          
          <div className="flex bg-slate-200/50 p-1 rounded-lg w-full md:w-auto overflow-x-auto select-none">
            {(['all', 'faculty', 'technical', 'non-teaching'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveType(tab)}
                className={`px-4 py-2 text-xs font-extrabold rounded-md uppercase tracking-wider transition-all whitespace-nowrap focus:outline-none ${
                  activeType === tab 
                    ? 'bg-navy text-white shadow' 
                    : 'text-slate-600 hover:text-navy hover:bg-slate-200/30'
                }`}
              >
                {tab === 'all' ? 'All Roles' : tab === 'faculty' ? 'Faculty' : tab === 'technical' ? 'Technical/Lib' : 'Administration'}
              </button>
            ))}
          </div>

          <div className="relative w-full md:max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search faculty name or dept..."
              value={staffSearch}
              onChange={(e) => setStaffSearch(e.target.value)}
              className="w-full bg-white border border-slate-200 pl-9 pr-4 py-2 rounded-lg text-sm outline-none focus:border-navy"
            />
          </div>

        </div>

        {/* Staff listing grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Main Roster Column */}
          <div className="col-span-1 lg:col-span-8 space-y-6">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {filteredStaff.length > 0 ? (
                filteredStaff.map((person) => (
                  <div
                    key={person.id}
                    className="bg-slate-50/50 border border-slate-150 rounded-2xl p-6 transition-all hover:bg-slate-50 hover:shadow-md flex items-start gap-4"
                  >
                    {/* Circle badge */}
                    <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0 shadow-sm text-lg select-none">
                      {person.type === 'faculty' ? '👨‍🏫' : person.type === 'technical' ? '⚙️' : '💼'}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className="text-[10px] font-black uppercase text-gold/90 tracking-wide">
                          {person.department}
                        </span>
                        
                        {isAdmin && (
                          <div className="flex gap-1 shrink-0">
                            <button
                              onClick={() => handleEditClick(person)}
                              className="p-1 text-slate-400 hover:text-navy hover:bg-white rounded transition-colors"
                              title="Edit record"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteClick(person.id)}
                              className="p-1 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded transition-colors"
                              title="Remove staff member"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>

                      <h4 className="font-serif font-bold text-sm sm:text-base text-navy truncate">
                        {person.name}
                      </h4>
                      <p className="text-slate-500 text-xs mt-0.5">
                        {person.role}
                      </p>

                      <div className="flex gap-2 mt-3 select-none">
                        <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                          person.type === 'faculty' ? 'bg-indigo-50 text-indigo-600' :
                          person.type === 'technical' ? 'bg-emerald-50 text-emerald-600' :
                          'bg-amber-100 text-amber-800'
                        }`}>
                          {person.type}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-1 sm:col-span-2 bg-slate-50 border border-slate-200 rounded-2xl p-12 text-center text-slate-500 font-medium text-sm">
                  No staff members matched SAMS rosters criteria.
                </div>
              )}
            </div>

            {isAdmin && !editingId && (
              <button
                onClick={handleStartAdd}
                className="bg-navy hover:bg-navy-light text-white font-bold text-xs px-4 py-2.5 rounded-lg flex items-center gap-1.5 shadow"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>Register New Staff Member</span>
              </button>
            )}

          </div>

          {/* Configuration Form Column */}
          <div className="col-span-1 lg:col-span-4">
            
            {editingId ? (
              /* Staff Registrar form */
              <form onSubmit={handleSaveStaff} className="bg-white border-2 border-navy rounded-2xl p-6 shadow-xl space-y-4 text-xs">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <span className="font-serif font-extrabold text-navy text-sm uppercase tracking-wider">
                    {editingId === 'new' ? 'New Roster Register' : 'Edit Staff Record'}
                  </span>
                  <button
                    type="button"
                    onClick={resetForm}
                    className="text-slate-400 hover:text-slate-600 font-bold"
                  >
                    Cancel
                  </button>
                </div>

                <div>
                  <label className="block text-slate-600 font-black uppercase tracking-wider mb-1">Staff Full name *</label>
                  <input
                    type="text"
                    value={staffName}
                    onChange={(e) => setStaffName(e.target.value)}
                    required
                    placeholder="e.g., Prof. Rashmi Ranjan Ray"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-sm text-navy outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 font-black uppercase tracking-wider mb-1">Official Role *</label>
                  <input
                    type="text"
                    value={staffRole}
                    onChange={(e) => setStaffRole(e.target.value)}
                    required
                    placeholder="e.g., HOD & Lecturer in Education"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-sm text-navy outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 font-black uppercase tracking-wider mb-1">Division Segment</label>
                    <select
                      value={staffType}
                      onChange={(e) => setStaffType(e.target.value as StaffType)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs text-navy outline-none"
                    >
                      <option value="faculty">Academic Faculty</option>
                      <option value="technical">Technical/Labs</option>
                      <option value="non-teaching">Administration / Office</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-600 font-black uppercase tracking-wider mb-1">Official Department</label>
                    <input
                      type="text"
                      value={staffDept}
                      onChange={(e) => setStaffDept(e.target.value)}
                      placeholder="e.g., Arts Division"
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs text-navy outline-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gold hover:bg-gold-light text-navy font-bold py-2.5 rounded-lg text-xs tracking-wider uppercase shadow"
                >
                  Save Registration Record
                </button>
              </form>
            ) : (
              /* Administrative details card */
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 shadow-tiny">
                <h4 className="font-serif font-extrabold text-navy pb-2 border-b border-slate-200 text-sm uppercase tracking-wider mb-3 flex items-center gap-1.5">
                  <Briefcase className="w-4 h-4 text-navy" />
                  <span>Administrative Guidelines</span>
                </h4>
                <p className="text-slate-400 text-[11px] leading-relaxed mb-4">
                  All personnel on this list hold validated service agreements registered with the Higher Education desk under Odisha fully-aided structural clauses.
                </p>
                <div className="space-y-3">
                  <div className="flex gap-2.5 items-start">
                    <div className="w-5 h-5 rounded bg-white shadow-tiny border flex items-center justify-center font-bold text-xs text-navy select-none">H</div>
                    <div className="text-[11px] text-slate-500 leading-relaxed">
                      Faculty coordinates academic syllabi, college seminars, and student mentoring.
                    </div>
                  </div>
                  <div className="flex gap-2.5 items-start">
                    <div className="w-5 h-5 rounded bg-white shadow-tiny border flex items-center justify-center font-bold text-xs text-navy select-none">T</div>
                    <div className="text-[11px] text-slate-500 leading-relaxed">
                      Technical personnel manage science laboratories, inventory lists, and library.
                    </div>
                  </div>
                </div>
              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
}
