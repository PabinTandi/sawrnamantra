import React, { useState } from 'react';
import { HeroState } from '../types';
import { GraduationCap, Compass, Sparkles, Award, Edit, Save, Undo2 } from 'lucide-react';

interface HeroProps {
  data: HeroState;
  isAdmin: boolean;
  onUpdate: (updated: HeroState) => void;
}

export default function Hero({ data, isAdmin, onUpdate }: HeroProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<HeroState>({ ...data });

  // Sync state if prop changes
  const handleStartEdit = () => {
    setFormData({ ...data });
    setIsEditing(true);
  };

  const handleSave = () => {
    onUpdate(formData);
    setIsEditing(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center overflow-hidden bg-navy pt-24 pb-12 select-none"
    >
      {/* Background grids */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(201,150,10,0.15),transparent_50%),radial-gradient(circle_at_80%_20%,rgba(37,99,235,0.18),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(201,150,10,0.04),transparent_70%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[linear-gradient(to_bottom,rgba(13,33,55,0.4),rgba(13,33,55,1))] pointer-events-none" />
      
      {/* Absolute decorative circle rails */}
      <div className="absolute -right-36 top-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full border border-gold/15 pointer-events-none flex items-center justify-center">
        <div className="w-[500px] h-[500px] rounded-full border border-gold/10 flex items-center justify-center">
          <div className="w-[400px] h-[400px] rounded-full border border-gold/5" />
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Main content column */}
          <div className="lg:col-span-7 flex flex-col items-start text-left animate-fade-up">
            
            {/* Admin Badge Toggler */}
            {isAdmin && !isEditing && (
              <button
                onClick={handleStartEdit}
                className="mb-4 bg-amber-500 hover:bg-amber-400 text-navy text-xs font-extrabold px-3 py-1.5 rounded-lg flex items-center gap-1 shadow-lg transition-transform hover:scale-105"
              >
                <Edit className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Configure Hero Copy</span>
              </button>
            )}

            {isEditing ? (
              /* Inline Section Editor Panel */
              <div className="w-full bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/25 shadow-xl max-w-2xl mb-8">
                <div className="flex items-center justify-between mb-4 pb-2 border-b border-white/10">
                  <div className="flex items-center gap-1.5 text-gold-light text-sm font-bold uppercase tracking-wider">
                    <Sparkles className="w-4 h-4" />
                    <span>Hero Copy Module</span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setIsEditing(false)}
                      className="px-2.5 py-1 text-xs bg-white/10 text-white/80 hover:bg-white/20 rounded font-bold flex items-center gap-1"
                    >
                      <Undo2 className="w-3 h-3" /> Cancel
                    </button>
                    <button
                      onClick={handleSave}
                      className="px-2.5 py-1 text-xs bg-gold text-navy hover:bg-gold-light rounded font-extrabold flex items-center gap-1"
                    >
                      <Save className="w-3 h-3" /> Save Changes
                    </button>
                  </div>
                </div>

                <div className="space-y-4 text-xs font-sans text-white/90">
                  <div>
                    <label className="block text-gold/90 font-bold mb-1 uppercase tracking-wider">Eyebrow Announcement</label>
                    <input
                      type="text"
                      name="eyebrow"
                      value={formData.eyebrow}
                      onChange={handleChange}
                      className="w-full bg-navy/60 border border-white/15 px-3 py-2 rounded text-white text-sm outline-none focus:border-gold-light"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gold/90 font-bold mb-1 uppercase tracking-wider">Title First Half</label>
                      <input
                        type="text"
                        name="title"
                        value={formData.title}
                        onChange={handleChange}
                        className="w-full bg-navy/60 border border-white/15 px-3 py-2 rounded text-white text-sm outline-none focus:border-gold-light"
                      />
                    </div>
                    <div>
                      <label className="block text-gold/90 font-bold mb-1 uppercase tracking-wider">Accent Second Half</label>
                      <input
                        type="text"
                        name="titleAccent"
                        value={formData.titleAccent}
                        onChange={handleChange}
                        className="w-full bg-navy/60 border border-white/15 px-3 py-2 rounded text-white text-sm outline-none focus:border-gold-light"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-gold/90 font-bold mb-1 uppercase tracking-wider">Slogan / Tagline Paragraph</label>
                    <textarea
                      name="tagline"
                      rows={3}
                      value={formData.tagline}
                      onChange={handleChange}
                      className="w-full bg-navy/60 border border-white/15 px-3 py-2 rounded text-white text-sm outline-none focus:border-gold-light resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-4 gap-2">
                    <div>
                      <label className="block text-gold/80 font-bold text-[10px] mb-0.5">Students stat</label>
                      <input type="text" name="statStudents" value={formData.statStudents} onChange={handleChange} className="w-full bg-navy/50 border border-white/10 p-1.5 rounded text-white text-xs text-center" />
                    </div>
                    <div>
                      <label className="block text-gold/80 font-bold text-[10px] mb-0.5">Faculty stat</label>
                      <input type="text" name="statTeachers" value={formData.statTeachers} onChange={handleChange} className="w-full bg-navy/50 border border-white/10 p-1.5 rounded text-white text-xs text-center" />
                    </div>
                    <div>
                      <label className="block text-gold/80 font-bold text-[10px] mb-0.5">Year stat</label>
                      <input type="text" name="statEstablish" value={formData.statEstablish} onChange={handleChange} className="w-full bg-navy/50 border border-white/10 p-1.5 rounded text-white text-xs text-center" />
                    </div>
                    <div>
                      <label className="block text-gold/80 font-bold text-[10px] mb-0.5">Success rate</label>
                      <input type="text" name="statSuccessRate" value={formData.statSuccessRate} onChange={handleChange} className="w-full bg-navy/50 border border-white/10 p-1.5 rounded text-white text-xs text-center" />
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* Public Presentation view */
              <>
                <div className="inline-flex items-center gap-2 text-gold-light font-semibold text-xs tracking-widest uppercase mb-4">
                  <span className="w-7 h-0.5 bg-gold rounded-full" />
                  <span>{data.eyebrow}</span>
                </div>

                <h1 className="font-serif font-black text-white text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.08] tracking-tight mb-6">
                  {data.title}
                  <span className="block mt-1 bg-gradient-to-r from-gold-light via-yellow-200 to-amber-300 bg-clip-text text-transparent font-medium italic">
                    {data.titleAccent}
                  </span>
                </h1>

                <p className="text-white/70 text-base md:text-lg font-light leading-relaxed max-w-xl mb-8">
                  {data.tagline}
                </p>

                <div className="flex items-center gap-4 flex-wrap">
                  <a
                    href="#admissions"
                    className="bg-gold hover:bg-gold-light text-navy text-sm sm:text-base font-bold px-6 py-3.5 rounded-xl transition-all duration-200 hover:-translate-y-0.5 hover:shadow-gold flex items-center gap-2 shrink-0 shadow-lg"
                  >
                    <GraduationCap className="w-5 h-5 stroke-[2.5]" />
                    <span>Apply Now</span>
                  </a>
                  <a
                    href="#academics"
                    className="border-2 border-white/40 hover:border-white bg-transparent hover:bg-white/10 text-white text-sm sm:text-base font-semibold px-6 py-3.5 rounded-xl transition-all duration-200 hover:-translate-y-0.5 flex items-center gap-2 shrink-0"
                  >
                    <Compass className="w-5 h-5" />
                    <span>Explore Academics</span>
                  </a>
                </div>
              </>
            )}

            {/* Quick stats grid */}
            <div className="flex gap-8 sm:gap-14 mt-12 pt-8 border-t border-white/10 flex-wrap w-full">
              <div>
                <div className="font-serif text-3xl font-extrabold text-white flex items-baseline gap-1">
                  {data.statStudents}
                </div>
                <div className="text-xs text-white/50 tracking-wider uppercase mt-1">Students enrolled</div>
              </div>
              <div>
                <div className="font-serif text-3xl font-extrabold text-white flex items-baseline gap-1">
                  {data.statTeachers}
                </div>
                <div className="text-xs text-white/50 tracking-wider uppercase mt-1">Expert Teachers</div>
              </div>
              <div>
                <div className="font-serif text-3xl font-extrabold text-white">
                  {data.statEstablish}
                </div>
                <div className="text-xs text-white/50 tracking-wider uppercase mt-1">Established</div>
              </div>
              <div>
                <div className="font-serif text-3xl font-extrabold text-gold-light">
                  {data.statSuccessRate}
                </div>
                <div className="text-xs text-white/50 tracking-wider uppercase mt-1">SAMS Score Rate</div>
              </div>
            </div>

          </div>

          {/* Right Column Badge Collage */}
          <div className="hidden lg:col-span-5 relative h-[380px] flex items-center justify-center">
            <div className="relative w-72 h-72 rounded-3xl bg-gradient-to-tr from-navy-mid to-navy-light border border-white/10 shadow-2xl flex flex-col items-center justify-center p-8 text-center bg-zinc-900/40 backdrop-blur-sm select-none">
              
              <div className="absolute -top-6 -left-6 bg-gold text-navy w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transform -rotate-12 transition-transform hover:rotate-0">
                <Award className="w-6 h-6 stroke-[2]" />
              </div>
              
              <div className="absolute -bottom-6 -right-6 bg-navy text-gold w-16 h-16 rounded-3xl flex items-center justify-center border border-gold/30 shadow-lg transform rotate-12 transition-transform hover:rotate-0">
                <GraduationCap className="w-8 h-8 stroke-[1.5]" />
              </div>

              <div className="w-20 h-20 bg-white/5 border border-white/10 rounded-full flex items-center justify-center text-gold mb-4 text-3xl transition-transform hover:scale-105 duration-300">
                🏫
              </div>
              <h3 className="font-serif text-white font-bold text-lg mb-2">Aided Degree College</h3>
              <p className="text-white/60 text-xs leading-relaxed max-w-[200px]">
                Registered under Section 2(f) and 12(B) of UGC Act. Fully aided under Higher Education Odisha.
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
