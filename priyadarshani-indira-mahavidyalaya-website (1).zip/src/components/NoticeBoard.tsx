import React, { useState } from 'react';
import { NoticeState, NoticeType } from '../types';
import { 
  Bell, Megaphone, Newspaper, FileCheck, Plus, Trash2, 
  Edit, Search, Sparkles, Calendar, ExternalLink, AlertCircle, RefreshCw 
} from 'lucide-react';

interface NoticeBoardProps {
  notices: NoticeState[];
  isAdmin: boolean;
  onUpdate: (updated: NoticeState[]) => void;
}

export default function NoticeBoard({ notices, isAdmin, onUpdate }: NoticeBoardProps) {
  const [activeTab, setActiveTab] = useState<'all' | NoticeType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Notice Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formType, setFormType] = useState<NoticeType>('exam');
  const [formTitle, setFormTitle] = useState('');
  const [formDate, setFormDate] = useState('');
  const [formUrl, setFormUrl] = useState('#');
  
  // AI Drafting Assist state
  const [showAiHelper, setShowAiHelper] = useState(false);
  const [aiConcept, setAiConcept] = useState('');
  const [aiDraftType, setAiDraftType] = useState<NoticeType>('exam');
  const [aiTone, setAiTone] = useState<'formal' | 'urgent' | 'celebratory'>('formal');
  const [aiIsGenerating, setAiIsGenerating] = useState(false);

  // Filter notices
  const filteredNotices = notices.filter(item => {
    const matchesTab = activeTab === 'all' || item.type === activeTab;
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesSearch;
  });

  // Action: Add/Save Notice
  const handleSaveNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) return;

    const noticeDate = formDate || new Date().toISOString().split('T')[0];

    if (editingId === 'new') {
      const newNotice: NoticeState = {
        id: `notice-${Date.now()}`,
        type: formType,
        title: formTitle,
        date: noticeDate,
        url: formUrl || '#',
        isNew: true
      };
      onUpdate([newNotice, ...notices]);
    } else if (editingId) {
      const updated = notices.map(item => 
        item.id === editingId 
          ? { ...item, type: formType, title: formTitle, date: noticeDate, url: formUrl } 
          : item
      );
      onUpdate(updated);
    }
    resetForm();
  };

  const resetForm = () => {
    setEditingId(null);
    setFormTitle('');
    setFormType('exam');
    setFormDate('');
    setFormUrl('#');
  };

  const handleEditClick = (notice: NoticeState) => {
    setEditingId(notice.id);
    setFormType(notice.type);
    setFormTitle(notice.title);
    setFormDate(notice.date);
    setFormUrl(notice.url);
  };

  const handleDeleteClick = (id: string) => {
    if (window.confirm('Are you sure you want to delete this notice?')) {
      const updated = notices.filter(item => item.id !== id);
      onUpdate(updated);
    }
  };

  const handleStartAdd = () => {
    resetForm();
    setEditingId('new');
    setFormDate(new Date().toISOString().split('T')[0]);
  };

  // Local AI-Style Draft Engine (Fallback & Instant response)
  const handleGenerateLocalDraft = () => {
    if (!aiConcept.trim()) return;
    setAiIsGenerating(true);

    setTimeout(() => {
      let title = '';
      const collegeHeader = aiTone === 'urgent' ? '⚠️ URGENT ANNOUNCEMENT: ' : aiTone === 'celebratory' ? '🎉 CONGRATULATIONS: ' : 'OFFICIAL NOTICE: ';
      
      if (aiDraftType === 'exam') {
        title = `${collegeHeader}Semester examination schedules shifted. Practical and project modules relating to ${aiConcept} are rescheduled accordingly. Check desk charts.`;
      } else if (aiDraftType === 'news') {
        title = `${collegeHeader}Achievement peak in campus life! Student delegations won state accolades in ${aiConcept}. Academic heads extended hearty congratulations.`;
      } else {
        title = `${collegeHeader}Revised selection list & board merit criteria relative to ${aiConcept} has been officially recorded and declared.`;
      }

      setFormTitle(title);
      setFormType(aiDraftType);
      setEditingId('new');
      setFormDate(new Date().toISOString().split('T')[0]);
      setShowAiHelper(false);
      setAiConcept('');
      setAiIsGenerating(false);
    }, 700);
  };

  const getIconForType = (type: NoticeType) => {
    switch (type) {
      case 'exam': return <Bell className="w-5 h-5 text-red-500" />;
      case 'news': return <Newspaper className="w-5 h-5 text-emerald-500" />;
      case 'results': return <FileCheck className="w-5 h-5 text-amber-500" />;
    }
  };

  return (
    <section id="notices" className="py-20 bg-slate-50 border-y border-slate-200 select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header and Intro */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="bg-navy/10 text-navy px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">
            Bulletin Board
          </span>
          <h2 className="font-serif font-bold text-3xl sm:text-4xl text-navy mt-4">
            Notice & Announcements Portal
          </h2>
          <div className="w-[60px] h-1 bg-gold mx-auto mt-4 mb-4 rounded" />
          <p className="text-slate-500 text-sm sm:text-base">
            Keep updated with latest circulars, semester calendars, technical results, and college events published daily.
          </p>
        </div>

        {/* Notices Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Main List Column */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Nav Filters & News Search bar */}
            <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
              
              {/* Category buttons */}
              <div className="flex bg-slate-100 p-1 rounded-lg w-full md:w-auto overflow-x-auto shrink-0 select-none">
                {(['all', 'exam', 'news', 'results'] as const).map(tab => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-4 py-2 text-xs font-bold rounded-md uppercase tracking-wider transition-colors whitespace-nowrap focus:outline-none ${
                      activeTab === tab 
                        ? 'bg-navy text-white shadow-sm' 
                        : 'text-slate-600 hover:text-navy hover:bg-slate-200/50'
                    }`}
                  >
                    {tab === 'all' ? 'All Notices' : tab === 'exam' ? 'Exams' : tab === 'news' ? 'News Clips' : 'Results'}
                  </button>
                ))}
              </div>

              {/* Keyword Search */}
              <div className="relative w-full md:max-w-xs">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Filter notice keywords..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 pl-9 pr-4 py-2 rounded-lg text-sm outline-none focus:bg-white focus:ring-2 focus:ring-navy-light/10 focus:border-navy"
                />
              </div>

            </div>

            {/* List Grid view */}
            <div className="space-y-3 max-h-[550px] overflow-y-auto pr-2 dark-scroll scrollbar-thin">
              {filteredNotices.length > 0 ? (
                filteredNotices.map((notice) => (
                  <div
                    key={notice.id}
                    className={`bg-white hover:bg-slate-50/70 border rounded-xl p-5 shadow-sm transition-all flex items-start gap-4 hover:-translate-y-0.5 hover:shadow-md ${
                      notice.isNew ? 'border-amber-400 bg-amber-50/30' : 'border-slate-200'
                    }`}
                  >
                    {/* Circle icon */}
                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center shrink-0 shadow-inner">
                      {getIconForType(notice.type)}
                    </div>

                    {/* Notice item texts */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                        <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded ${
                          notice.type === 'exam' ? 'bg-red-50 text-red-600 border border-red-200' :
                          notice.type === 'news' ? 'bg-emerald-50 text-emerald-600 border border-emerald-200' :
                          'bg-amber-100 text-amber-800 border border-amber-300'
                        }`}>
                          {notice.type}
                        </span>
                        <span className="text-slate-400 text-xs flex items-center gap-1 font-medium">
                          <Calendar className="w-3.5 h-3.5" />
                          {notice.date}
                        </span>
                        {notice.isNew && (
                          <span className="bg-amber-500 text-navy text-[9px] font-black px-1.5 py-0.5 rounded tracking-widest uppercase animate-pulse">
                            NEW UPDATE
                          </span>
                        )}
                      </div>
                      <h4 className="text-navy text-sm font-semibold leading-relaxed tracking-tight group hover:text-gold transition-colors">
                        {notice.title}
                      </h4>
                      <div className="flex gap-4 mt-2">
                        <a
                          href={notice.url}
                          className="text-xs text-blue-600 hover:text-blue-800 font-bold inline-flex items-center gap-1"
                        >
                          <span>PDF Download</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>

                    {/* Admin Action triggers */}
                    {isAdmin && (
                      <div className="flex gap-1 shrink-0">
                        <button
                          onClick={() => handleEditClick(notice)}
                          className="p-1.5 text-slate-500 hover:text-navy hover:bg-slate-100 rounded-lg transition-colors"
                          title="Edit notice details"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteClick(notice.id)}
                          className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete Notice"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                ))
              ) : (
                <div className="bg-white border border-slate-200 rounded-xl p-12 text-center text-slate-500 shadow-sm leading-relaxed">
                  <AlertCircle className="w-8 h-8 mx-auto text-slate-400 mb-2" />
                  <p className="font-semibold text-sm">No announcements matching the search criteria.</p>
                  <p className="text-xs text-slate-400 mt-1">Try switching to "All Notices" or clearing filters.</p>
                </div>
              )}
            </div>

            {/* Quick Helper Badge */}
            {isAdmin && (
              <div className="flex justify-start gap-3">
                <button
                  onClick={handleStartAdd}
                  className="bg-navy hover:bg-navy-light text-white text-xs font-bold px-4 py-2.5 rounded-lg flex items-center gap-1.5 shadow-md"
                >
                  <Plus className="w-4 h-4 stroke-[2.5]" />
                  <span>Manual Add Notice</span>
                </button>
                <button
                  onClick={() => setShowAiHelper(!showAiHelper)}
                  className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white text-xs font-bold px-4 py-2.5 rounded-lg flex items-center gap-1.5 shadow-md"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Draft Notice with Intelligence</span>
                </button>
              </div>
            )}

          </div>

          {/* Editor Sandbox Column */}
          <div className="lg:col-span-4">
            
            {/* Form Drawer (Conditional on Editing or creating) */}
            {editingId ? (
              <form onSubmit={handleSaveNotice} className="bg-white border-2 border-navy rounded-2xl p-6 shadow-xl space-y-4">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <h4 className="font-serif font-bold text-navy text-sm uppercase tracking-wide">
                    {editingId === 'new' ? 'Create New Notice' : 'Edit Notice Block'}
                  </h4>
                  <button
                    type="button"
                    onClick={resetForm}
                    className="text-xs text-slate-400 hover:text-slate-600 font-semibold"
                  >
                    Cancel
                  </button>
                </div>

                {/* Form fields */}
                <div>
                  <label className="block text-slate-600 text-[11px] font-bold uppercase tracking-wider mb-1">Broad Channel</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as NoticeType)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-sm text-navy outline-none"
                  >
                    <option value="exam">Exam Announcement</option>
                    <option value="news">News / Achievement Clip</option>
                    <option value="results">Academic Results Report</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 text-[11px] font-bold uppercase tracking-wider mb-1 font-sans">Announcement Copy *</label>
                  <textarea
                    rows={4}
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    required
                    placeholder="Enter formal notice copy exactly as it will display..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 text-sm text-slate-800 outline-none focus:bg-white focus:border-navy"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 text-[11px] font-bold uppercase tracking-wider mb-1">Notice Date</label>
                    <input
                      type="date"
                      value={formDate}
                      onChange={(e) => setFormDate(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs text-navy outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 text-[11px] font-bold uppercase tracking-wider mb-1">Target Document URL</label>
                    <input
                      type="text"
                      value={formUrl}
                      onChange={(e) => setFormUrl(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs text-navy outline-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gold hover:bg-gold-light text-navy font-bold py-2.5 rounded-lg text-xs tracking-wider uppercase shadow"
                >
                  Save to Main Board
                </button>
              </form>
            ) : showAiHelper ? (
              /* AI Drafting Board */
              <div className="bg-gradient-to-b from-navy-mid to-navy rounded-2xl p-6 text-white shadow-xl space-y-4">
                <div className="flex items-center gap-1.5 text-gold-light text-sm font-serif font-bold tracking-wide">
                  <Sparkles className="w-4 h-4 text-gold-light animate-bounce" />
                  <span>AI Notice Composer</span>
                </div>
                
                <p className="text-[12px] text-white/70 leading-relaxed">
                  Enter secondary parameters (e.g. "summer vacation from June 1st", "Chemistry Practical lab shifts") and choose a tone to instantly generate formal academic notice copy.
                </p>

                <div>
                  <label className="block text-gold-pale/80 text-[10px] font-bold mb-1 uppercase tracking-wider">Focus Concept</label>
                  <input
                    type="text"
                    value={aiConcept}
                    onChange={(e) => setAiConcept(e.target.value)}
                    placeholder="e.g., Chess Tournament, Midterm delay"
                    className="w-full bg-white/10 border border-white/25 rounded-lg p-2.5 text-sm text-white placeholder-white/40 focus:outline-none focus:border-gold"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-gold-pale/80 text-[10px] font-bold mb-1 uppercase tracking-wider">Channel Target</label>
                    <select
                      value={aiDraftType}
                      onChange={(e) => setAiDraftType(e.target.value as NoticeType)}
                      className="w-full bg-white/10 border border-white/20 rounded-lg p-1.5 text-white outline-none [&>option]:bg-navy [&>option]:text-white"
                    >
                      <option value="exam">Examination</option>
                      <option value="news">News Clip</option>
                      <option value="results">Results Update</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-gold-pale/80 text-[10px] font-bold mb-1 uppercase tracking-wider">Draft Tone</label>
                    <select
                      value={aiTone}
                      onChange={(e) => setAiTone(e.target.value as 'formal' | 'urgent' | 'celebratory')}
                      className="w-full bg-white/10 border border-white/20 rounded-lg p-1.5 text-white outline-none [&>option]:bg-navy [&>option]:text-white"
                    >
                      <option value="formal">Formal Academic</option>
                      <option value="urgent">Highly Urgent</option>
                      <option value="celebratory">Celebratory</option>
                    </select>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => setShowAiHelper(false)}
                    className="flex-1 bg-white/10 hover:bg-white/20 text-white/95 font-bold py-2 rounded text-xs"
                  >
                    Collapse
                  </button>
                  <button
                    onClick={handleGenerateLocalDraft}
                    disabled={!aiConcept.trim() || aiIsGenerating}
                    className="flex-1 bg-gold hover:bg-gold-light disabled:bg-slate-500 disabled:text-slate-200 text-navy font-bold py-2 rounded text-xs flex items-center justify-center gap-1"
                  >
                    {aiIsGenerating ? (
                      <>
                        <RefreshCw className="w-3 h-3 animate-spin" />
                        <span>Composing...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3 h-3 text-navy" />
                        <span>Generate Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            ) : (
              /* Simple Instructions Sidebar Card */
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
                <h4 className="font-serif font-bold text-navy text-sm uppercase tracking-wide mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-gold" />
                  College News Desk
                </h4>
                <p className="text-slate-500 text-xs leading-relaxed mb-4">
                  The Notice Board displays critical student directives. Fully aided degree college directives are subject to state regulation under Higher Education guidelines of Odisha SAMS.
                </p>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-3">
                  <div className="flex items-start gap-2 text-[11px] font-medium text-slate-600">
                    <span className="text-red-500 font-bold">●</span>
                    <span>Exam announcements contain rescheduled paper structures.</span>
                  </div>
                  <div className="flex items-start gap-2 text-[11px] font-medium text-slate-600">
                    <span className="text-emerald-500 font-bold">●</span>
                    <span>News Clips highlight national accomplishments.</span>
                  </div>
                  <div className="flex items-start gap-2 text-[11px] font-medium text-slate-600">
                    <span className="text-amber-500 font-bold">●</span>
                    <span>Results outline direct Common Application criteria scores.</span>
                  </div>
                </div>
              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
}
