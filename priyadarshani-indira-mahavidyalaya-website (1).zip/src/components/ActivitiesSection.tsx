import React, { useState } from 'react';
import { ActivityState } from '../types';
import { 
  X, Compass, Shield, HeartHandshake, Award, Bus, HelpCircle, 
  Sparkles, Save, Edit, BookOpenCheck 
} from 'lucide-react';

interface ActivitiesSectionProps {
  activities: ActivityState[];
  isAdmin: boolean;
  onUpdate: (updated: ActivityState[]) => void;
}

export default function ActivitiesSection({ activities, isAdmin, onUpdate }: ActivitiesSectionProps) {
  // Detail Modal popup state
  const [activeActivity, setActiveActivity] = useState<ActivityState | null>(null);

  // Editing state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<ActivityState | null>(null);

  const getLucideIcon = (iconStr: string) => {
    switch (iconStr) {
      case 'hands-helping': return <HeartHandshake className="w-8 h-8 transition-transform" />;
      case 'shield-alt': return <Shield className="w-8 h-8 transition-transform" />;
      case 'medkit': return <Compass className="w-8 h-8 transition-transform" strokeWidth={2} />;
      case 'bus-alt': return <Bus className="w-8 h-8 transition-transform" />;
      case 'trophy': return <Award className="w-8 h-8 transition-transform" />;
      default: return <HelpCircle className="w-8 h-8 transition-transform" />;
    }
  };

  const handleStartEdit = (e: React.MouseEvent, act: ActivityState) => {
    e.stopPropagation(); // Avoid opening the detail dialog
    setFormData({ ...act });
    setEditingId(act.id);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData) return;

    const updated = activities.map(item => item.id === formData.id ? formData : item);
    onUpdate(updated);
    setEditingId(null);
    setFormData(null);
  };

  return (
    <section id="activities" className="py-24 bg-navy text-white select-none relative overflow-hidden">
      
      {/* Visual background grids */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_left_bottom,rgba(201,150,10,0.06),transparent_40%)]" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Intro */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="bg-white/10 text-gold-light border border-white/10 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">
            Campus Enrichment
          </span>
          <h2 className="font-serif font-bold text-3xl sm:text-4xl text-white mt-4">
            Beyond the <span className="text-gold-light">Classroom Walls</span>
          </h2>
          <div className="w-[60px] h-1 bg-gold mx-auto mt-4 mb-4 rounded" />
          <p className="text-white/60 text-sm">
            Discover a rich portfolio of disciplined training, social extension modules, industrial expeditions, and community service leagues.
          </p>
        </div>

        {/* Card Grid list */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {activities.map((act) => (
            <div
              key={act.id}
              onClick={() => setActiveActivity(act)}
              className="bg-white/5 border border-white/10 hover:border-gold/40 hover:bg-gold hover:text-navy group rounded-2xl p-6 text-center shadow transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between items-center cursor-pointer min-h-[220px]"
            >
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-white/5 group-hover:bg-navy/10 flex items-center justify-center text-gold-light group-hover:text-navy transition-all duration-300 mb-4">
                  {getLucideIcon(act.icon)}
                </div>

                <h3 className="font-serif text-sm sm:text-base font-bold mb-2 group-hover:text-navy transition-colors">
                  {act.title}
                </h3>
                <p className="text-white/60 group-hover:text-navy/80 text-[11px] sm:text-xs leading-relaxed line-clamp-3">
                  {act.description}
                </p>
              </div>

              {/* Admin triggers */}
              {isAdmin && (
                <div className="mt-4 pt-4 border-t border-white/10 group-hover:border-navy/10 w-full flex justify-center">
                  <button
                    onClick={(e) => handleStartEdit(e, act)}
                    className="flex items-center gap-1.5 bg-navy text-white group-hover:bg-navy group-hover:text-gold text-[10px] font-black uppercase tracking-wider py-1 px-3 rounded-md shadow"
                  >
                    <Edit className="w-3 h-3 text-gold" />
                    <span>Edit</span>
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

      </div>

      {/* Activity Details Modal Popup */}
      {activeActivity && editingId !== activeActivity.id && (
        <div className="fixed inset-0 z-50 bg-navy-mid/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl text-navy relative border border-slate-200 animate-fade-up">
            <button
              onClick={() => setActiveActivity(null)}
              className="absolute top-4 right-4 p-1 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="w-16 h-16 rounded-2xl bg-gold-pale text-gold flex items-center justify-center text-2xl mb-4">
              ✨
            </div>

            <h3 className="font-serif font-bold text-xl text-navy mb-2">
              {activeActivity.title}
            </h3>
            <p className="text-slate-600 text-sm leading-relaxed mb-6">
              {activeActivity.description}
            </p>

            <div className="bg-slate-50 p-4 border border-slate-150 rounded-2xl text-slate-500 text-xs flex gap-2">
              <BookOpenCheck className="w-5 h-5 text-navy shrink-0" />
              <span>
                To volunteer or enlist, reach out directly during our student orientation schedules or contact our staff coordinator.
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Roster Editor mini popup modal dialog */}
      {editingId && formData && (
        <div className="fixed inset-0 z-50 bg-navy/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSave}
            className="bg-white text-navy rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 border border-slate-150 animate-fade-up"
          >
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="font-serif font-bold text-navy text-sm uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-4 h-4 text-gold" />
                <span>Configure Student Activity Block</span>
              </span>
              <button
                type="button"
                onClick={() => setEditingId(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div>
              <label className="block text-slate-600 font-extrabold text-[10px] uppercase tracking-wider mb-1">Activity title *</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-sm text-navy outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-600 font-extrabold text-[10px] uppercase tracking-wider mb-1">Narrative Description</label>
              <textarea
                rows={4}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs text-slate-800 outline-none resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-navy hover:bg-navy-light text-white font-bold py-2.5 rounded-lg text-xs uppercase tracking-wider"
            >
              Apply Updates
            </button>
          </form>
        </div>
      )}

    </section>
  );
}
