import { useState, useEffect } from 'react';
import { Menu, X, Shield, Settings2, GraduationCap } from 'lucide-react';
import Logo from './Logo';

interface HeaderProps {
  isAdmin: boolean;
  setIsAdmin: (admin: boolean) => void;
}

export default function Header({ isAdmin, setIsAdmin }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Academics', href: '#academics' },
    { name: 'Student Life', href: '#activities' },
    { name: 'Administration', href: '#staff' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav
      id="navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled || isAdmin
          ? 'bg-navy/95 backdrop-blur-md shadow-lg py-3 border-b border-white/10'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <a href="#" className="flex items-center gap-3 shrink-0 focus:outline-none select-none">
            <Logo size={44} className="bg-white rounded-xl p-0.5 border border-white/20 shadow-md flex items-center justify-center" />
            <div className="leading-tight">
              <div className="font-serif font-bold text-white text-base sm:text-lg tracking-tight">
                Priyadarshani Indira Mahavidyalaya
              </div>
              <div className="text-[10px] text-white/65 font-medium letter-spacing-[0.08em] uppercase">
                Est. 1985 · Aided College
              </div>
            </div>
          </a>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-white/80 hover:text-white hover:bg-white/10 px-3 py-2 rounded-lg transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* Right Action Widgets */}
          <div className="hidden sm:flex items-center gap-3">
            <a
              href="#admissions"
              className="bg-gold hover:bg-gold-light text-navy text-sm font-bold px-4 py-2 rounded-lg transition-all shadow-md flex items-center gap-1.5 focus:outline-none"
            >
              <GraduationCap className="w-4 h-4 stroke-[2.5]" />
              <span>Apply Now</span>
            </a>
          </div>

          {/* Mobile Right Controls */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => setIsAdmin(!isAdmin)}
              className={`p-2 rounded-lg transition-all ${
                isAdmin ? 'bg-amber-500/20 text-amber-300' : 'bg-white/10 text-white/90'
              }`}
            >
              <Settings2 className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-white/10 text-white hover:bg-white/20 transition-all border border-white/5"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Admin Mode Bar Under Nav */}
      {isAdmin && (
        <div className="bg-amber-500 text-navy font-bold text-[11px] py-1 text-center select-none shadow-sm flex items-center justify-center gap-2">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-red-600"></span>
          </span>
          <span>ADMINISTRATIVE CONTENT BUILDER ACTIVE — CLICK ANY HIGHLIGHT DRIVEN SECTION OR EDIT CARD CODES</span>
        </div>
      )}

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden absolute top-[100%] inset-x-0 bg-navy/98 backdrop-blur-xl border-b border-white/10 py-6 px-4 flex flex-col gap-3 shadow-xl transition-all duration-300">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className="text-lg font-medium text-white/90 hover:text-gold-light p-3 rounded-lg hover:bg-white/5 transition-all text-center"
            >
              {link.name}
            </a>
          ))}
          <div className="flex flex-col gap-2 pt-4 border-t border-white/10 text-center">
            <a
              href="#admissions"
              onClick={() => setMobileMenuOpen(false)}
              className="bg-gold text-navy text-base font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 shadow-md w-full"
            >
              <GraduationCap className="w-5 h-5 stroke-[2.5]" />
              <span>Apply Online 2026</span>
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}
